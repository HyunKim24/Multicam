#  개발 환경 구축
pip install -r requirements.txt