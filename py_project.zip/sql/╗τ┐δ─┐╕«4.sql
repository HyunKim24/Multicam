-- 테이블 삭제
# drop table tbl_fileBbs;

-- 데이터 추가
#insert into 
#	tbl_fileBbs
#(title, content, `author`, `files`)
#	values
#('1','2','m','Desert.jpg');

-- 자료실 데이터 가져오기
select * from tbl_fileBbs order by id desc limit 10;


