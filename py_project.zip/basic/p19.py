################################################
# 내장함수 
# 1) 파일 처리 
'''
파일 오픈: open()
> mode 옵션
 r -> 읽기 모드
 w -> 쓰기 모드
 b -> 바이너리 모드(데이터가 이진으로 구성)
 + -> 반대 속성을 추가할때 예 r+ -> rw
 a -> 추가하기 모드
 a+ -> 추가하고 읽기
 ab -> 바이너리 추가하기 
> encoding 옵션
 기술하지 않으면 2byte의 인코딩을 따라간다 (시스템에 의존)
 한글 -> 1byte는 utf-8 or utf8 를 사용->완성형코드, 글자->값매칭
      -> 2byte는 euc-kr을 사용 (초성,중성, 종성의 조합):유니코드
'''
f = open('a.txt', 'w', encoding='utf-8')
# 0~9까지 연속수 획득 for문으로 각각 획득
for n in range(10):
    '''
    파일에 쓰기 : 
    0번째 라인
    1번째 라인
    2번째 라인
    '''
    #print( str(n) + '번째 라인' )
    #print( '%s번째 라인' % n )
    f.write( '%s번째 라인\n' % n )
# 반드시 파일을 다 썻으면 닫아라
# I/O를 사용하면 반드시 닫는 코드를 생략하면 않된다
f.close()
#######################
# 파일 읽기
f = open('a.txt', 'r', encoding='utf-8')
# f.read() : 한번에 다읽어라
#print( f.read() )
# 한줄씩 읽어라
print( '='*30 )
while True:
    v = f.readline()    
    if not v:break
    print( v.strip() ) #줄바꿈 삭제처리 
print( '='*30 )   
f.close()
#################################################
# I/O 대상을 열면 받드시 닫아야 하는데
# 간혻 까먹는 경우가 종종 발생한다
# 자동으로 닫아 줬으면 좋겟다!! -> with문
# with문이끝아면 알아서 닫아준다
with open('a.txt', 'r', encoding='utf-8') as f:
    while True:
        v = f.readline()    
        if not v:break
        print( v.strip() ) #줄바꿈 삭제처리 
#f.close()
################################################
# 파일쪽에 응용 => 압축, 바이너리데이터 처리
# MINST (http://yann.lecun.com/exdb/mnist/)
# 데이터 인코딩 처리
################################################
# 외장함수 => 모듈가져오기
# 2) 구조형태를 유지하고 저장한다(리스트채로 저장, 딕셔너리 그대로 저장)
# pickle => 이부분은 향후 내가 만든 모델(딥러닝,머신러닝)을
# 저장해서 => 서비스나 시스템에 적용하는 방식으로 응용
# 버전을 할경우 모델을 교체함으로써 바로 적용이 되는 방식
##################################################
import pickle as p
data = {
    1:[1,2,3,4],
    "name":'multi',
    2:(5,6,7,8),
    3:{'age':10}
}
# 기록(덤프)
with open('data.p', 'wb') as f:
    p.dump( data, f, p.HIGHEST_PROTOCOL)
# 로드(값을 확인)
with open('data.p', 'rb') as f:
    #print( p.load( f ) )
    # age값 10을 출력하시오
    print( p.load( f )[3]['age'] )


