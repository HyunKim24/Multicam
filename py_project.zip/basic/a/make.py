def sum3(x,y):
    return x+y