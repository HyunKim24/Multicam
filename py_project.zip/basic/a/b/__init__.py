def sum2(x,y):
    return x+y