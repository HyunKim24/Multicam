def sum4(x,y):
    return x+y