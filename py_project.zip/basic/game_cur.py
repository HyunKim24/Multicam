while True:
    game_title = input("게임의 제목을 28자이내로 입력하세요\n")
    if not game_title:    
        print('게임 제목이 입력되지 않았습니다. 다시 입력하세요')
    elif len(game_title)>28:
        print('게임 제목이 28자를 초과합니다 다시 입력하세요')
    else:
        break

TITLE_LEN = 30
print( '='*TITLE_LEN )
txt  = '={0:^%s}=' % (TITLE_LEN-2)
data = [game_title, 'v 1.0.0', 'thanks K,K,S'] 
for t in data:
    print( txt.format(t) )
print( '='*TITLE_LEN )

flag = True
while flag:
    gamer_name = input('게이머의 이름을 입력하세요?\n')
    if not gamer_name:
        print('이름을 정확하게 넣으세요')        
        continue
    flag = False

# 임시 설정
#game_title = 'number match game'
#gamer_name = 'multi'