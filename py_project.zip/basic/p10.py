# 조건문
'''
조건이 1개
if 조건식:
    수행코드

조건이 2개
if 조건식:
    수행코드
else:
    수행코드

조건(케이스) > 2
if 조건식:
    수행코드
elif 조건식:
    수행코드
else:
    수행코드

'''
print('커피값을 지불해 주세요')
# input() : 콘솔에서 사용자 입력을 받는 함수
# 입력을 하고 엔터키를 칠때까지 블럭 대기 한다
# 사용자가 입력하고 엔터치면 ㄱ입려값을 리턴한다
# 리턴한 값의 타입은?
# 문자열 => 정수로 int()
money = int( input() )
# 2000원보다 작으면 => 적게 입력했다
# 2000원과   같으면 => 정상 지불했다
# 2000원보다 크면 잔돈을 계산해서 => 500원 잔돈입니다.
# 해당 수행문을 그대로 넘겨버리는것 pass
COFFEE_PRICE = 2000
if money < COFFEE_PRICE:
    print('적게 입력했다')
elif money == COFFEE_PRICE:
    print('정상 지불했다')
else:
    print('%s원 잔돈입니다.' % (money-COFFEE_PRICE) )
