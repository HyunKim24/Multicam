#!/usr/bin/env python
# coding: utf-8

# ## 1. 데이터 획득

# In[12]:


from urllib.request import urlopen, Request
import urllib
import json
# -----------------
import pymysql
from sqlalchemy import create_engine
import pandas as pd
import pandas.io.sql as pSql


# In[13]:


# 연결
db_url = 'mysql+pymysql://root:12341234@127.0.0.1/python_db'
engine = create_engine( db_url, encoding='utf8')
conn = engine.connect()


# In[3]:


# kakao REST API 키
KAKAO_REST_API_KEY = 'd99f329dfcdb238f998f101230a64885'
URL_BASE = 'https://dapi.kakao.com/v2/search/web'
# 1~50페이지까지 반복해야한다
PARAMS = 'query=%s&page=%s&size=50' % (urllib.parse.quote('서가대'),1)
HEADER = 'KakaoAK %s' % KAKAO_REST_API_KEY
url = '%s?%s' % (URL_BASE, PARAMS)
url


# In[17]:


# 반복 요청에 대한 확인 : 1~50은 kakao 제약사항
for page in range(1, 3):
    PARAMS = 'query=%s&page=%s&size=50' % (urllib.parse.quote('서가대'),page)
    url = '%s?%s' % (URL_BASE, PARAMS)
    #print( url )
    request = Request(url)
    request.add_header("Authorization", HEADER)
    response = urlopen( request )
    tmp = json.load( response )
    print( url, tmp['documents'][0]['title'] )
    # tmp(중에 dict) => dataFrame 변경
    df_dict = pd.DataFrame.from_dict( tmp['documents'] )
    #print( df_dict )
    # 데이터 전처리 부분 수행 --------------------------
    # 공백제거, 의미없는 데이터 삭제, 디비에 입력않되는
    # 값을 보정등등...
    # --------------------------------------------------
    # DataFrame => DB 입력
    df_dict.to_sql(name='seoul', con=conn, 
               if_exists='append', index=False)


# In[ ]:


# 해제
conn.close()


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




