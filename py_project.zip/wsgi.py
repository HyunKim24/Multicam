from flask_ex.start import app # 이 부분 수정
if __name__ == '__main__':
    app.run()