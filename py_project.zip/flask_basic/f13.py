# 템플릿 엔진에서 값찍기
# 전달: render_templaye('xx.html', 키=값, 키=값, 키=값..)
# 받는쪽(html) : 값출력 => {{ 키 }} 
from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    data = [
        { 'rank1':1, 'national1':'한국' },
        { 'rank1':2, 'national1':'미국' },
        { 'rank1':3, 'national1':'일본' }
    ]
    return render_template( 'index.html', items=data )

if __name__=='__main__':# 이코드를 메인으로 구동시 서버가동
    app.run(debug=True)
