-- delete from seoul;
select count(*) from seoul;